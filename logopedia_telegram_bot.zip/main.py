import telebot
import json
import random
import os

TOKEN = os.getenv("API_TOKEN") or "PASTE_YOUR_TOKEN_HERE"
bot = telebot.TeleBot(TOKEN)

with open("logopedia_test_var1.json", "r", encoding="utf-8") as f:
    questions = json.load(f)

user_data = {}

@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.chat.id
    user_data[user_id] = {
        "score": 0,
        "q_list": random.sample(questions, len(questions)),
        "current": 0
    }
    bot.send_message(user_id, "Привет! Начнем тест по логопедии.")
    send_question(user_id)

def send_question(user_id):
    data = user_data[user_id]
    if data["current"] < len(data["q_list"]):
        q = data["q_list"][data["current"]]
        markup = telebot.types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True)
        for ans in q["answers"]:
            markup.add(ans)
        bot.send_message(user_id, f"Вопрос {data['current'] + 1}: {q['question']}", reply_markup=markup)
    else:
        bot.send_message(user_id, f"Тест завершен. Правильных ответов: {data['score']} из {len(data['q_list'])}")
        del user_data[user_id]

@bot.message_handler(func=lambda m: True)
def handle_answer(message):
    user_id = message.chat.id
    if user_id not in user_data:
        bot.send_message(user_id, "Напиши /start, чтобы начать тест.")
        return
    data = user_data[user_id]
    current_q = data["q_list"][data["current"]]
    if message.text == current_q["correct"]:
        data["score"] += 1
    data["current"] += 1
    send_question(user_id)

bot.polling()
